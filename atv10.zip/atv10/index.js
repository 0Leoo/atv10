var h1 = document.createElement("h1")
var text = document.createTextNode("qualquer texto")

var header = document.querySelector("header")
header.appendChild("h1")

h1.document.querySelector("h1")
h1.appendChild('text')

var div1 = document.createElement(div)
var div2 = document.createElement(div)

var main = document.querySelector("main")

main.appendChild("div1")
main.appendChild("div2")

